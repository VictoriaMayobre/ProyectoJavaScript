function empezarJuego() {
    const numeroAleatorio = Math.floor(Math.random() * 100) + 1;
    let intentos = 10;
    let numeroAdivinado;
    const intentosAnteriores = [];

    while (intentos > 0) {
        numeroAdivinado = prompt("Adivina el numero del 1 al 100, numero de intentos restantes: " + intentos);
        if (numeroAdivinado === null) { // Chequea si el usario clickeo cancelar
            alert("Juego cancelado.");
            return;
        }
        numeroAdivinado = Number(numeroAdivinado);
        if (isNaN(numeroAdivinado) || numeroAdivinado < 1 || numeroAdivinado > 100) {
            alert("Numero invalido, porfavor ingresar un numero del 1 al 100.");
            continue;
        }
        intentos--;

        intentosAnteriores.push(numeroAdivinado);
        if (numeroAdivinado === numeroAleatorio) {
            alert("Felicitaciones, has adivinado el numero " + numeroAleatorio + ". Intentos usados " + (10 - intentos) + ".");
            break;
        } else if (intentos === 0) {
            alert("Te has qeudado sin intentos, el numero era: " + numeroAleatorio + ".");
        } else if (numeroAdivinado < numeroAleatorio) {
            alert("Muy bajo, intentos anteriores: " + intentosAnteriores.join(", "));
        } else {
            alert("Muy alto, intentos anteriores:  " + intentosAnteriores.join(", "));
        }
    }
}
